#include "StdAfx.h"
#include "Shape.h"


 void Shape::setWidth(int w) {
         width = w;
      }
 void Shape::setHeight(int h) {
         height = h;
      }
 void Shape::setBase(int b){
		base = b;
 }