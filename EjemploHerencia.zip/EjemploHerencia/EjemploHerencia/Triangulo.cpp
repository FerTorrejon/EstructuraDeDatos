#include "StdAfx.h"
#include "Triangulo.h"


Triangulo::Triangulo(void)
{
}


Triangulo::~Triangulo(void)
{
}
